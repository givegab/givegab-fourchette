require 'sinatra'

get '/' do
'<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="30">
<style>
  html, body {
      height:100%;
      width:100%;
      margin:0px;
  }
  body {
      display:table;
      vertical-align:middle;
      text-align:center;
  }
  div {
      display:table-cell;
      vertical-align:middle;
      font-size: 2em; 
  }
</style>
<title>Please Wait</title>
</head>
<body>
<div>Please Wait While Your Application Is Provisioned</div>
</body>
</html>'
end